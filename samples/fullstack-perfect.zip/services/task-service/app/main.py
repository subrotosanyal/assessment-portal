
from fastapi import FastAPI
app = FastAPI()
tasks=[]; tseq=1
@app.get('/tasks')
def list_tasks(): return tasks
@app.post('/tasks')
def add_task(t: dict):
    global tseq
    t={'id':tseq,'title':t['title'],'assignedTo':t['assignedTo']}; tseq+=1; tasks.append(t); return t
