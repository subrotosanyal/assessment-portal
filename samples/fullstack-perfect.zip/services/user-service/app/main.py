
from fastapi import FastAPI, HTTPException
app = FastAPI()
users=[]; seq=1
@app.get('/users')
def list_users(): return users
@app.post('/users')
def add_user(u: dict):
    global seq
    if not u.get('name') or '@' not in u.get('email',''): raise HTTPException(status_code=400)
    u={'id':seq,'name':u['name'],'email':u['email']}; seq+=1; users.append(u); return u
