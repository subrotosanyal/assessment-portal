# QA Test Plan: Cancer Detection Portal

## Objective
Validate correctness, input validation, and user experience of the Cancer Detection Portal UI.

## Scope
Functional tests covering user input, validation, image upload, and workflow completion.

---

### 1. Basic Rendering
- **Goal:** Verify page loads and displays expected heading.
- **Steps:**
  1. Launch the portal.
  2. Check for the heading “Cancer Detection Portal”.
- **Expected:** Page renders without error.

### 2. Positive Flow - Valid Image
- **Goal:** Confirm successful analysis with valid input.
- **Steps:**
  1. Fill name and age.
  2. Upload valid `.jpg`.
  3. Click “Run Analysis”.
- **Expected:** Message “Analysis complete” appears.

### 3. Negative Flow - Missing Name
- **Goal:** Validate required field enforcement.
- **Steps:**
  1. Leave “Patient Name” blank.
  2. Fill other fields.
  3. Click “Run Analysis”.
- **Expected:** Error “Patient name is required”.

### 4. Negative Flow - Invalid File
- **Goal:** Reject non-image uploads.
- **Steps:**
  1. Upload a `.txt` file.
  2. Click “Run Analysis”.
- **Expected:** Message “Invalid image”.

### 5. Edge Case - Boundary Age
- **Goal:** Ensure UI accepts high valid ages gracefully.
- **Steps:**
  1. Input age = 120.
  2. Upload valid image.
- **Expected:** Analysis runs successfully.

### 6. Reset Flow
- **Goal:** Ensure form reset works properly after analysis.
- **Steps:**
  1. Run analysis once.
  2. Click “Reset”.
- **Expected:** All fields cleared.

---

### 7. Non-Functional Checks
- UI should remain responsive during image upload.
- Messages should disappear when the user edits inputs.
- All error messages are in accessible text form (no hidden ARIA).

---

**Expected Result:**  
All test cases pass.  
Total score: 100/100 (20 from plan + 80 from tests)
