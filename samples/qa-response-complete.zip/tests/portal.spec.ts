import { test, expect } from '@playwright/test';

// Use BASE_URL or fallback
const BASE = process.env.BASE_URL || 'http://localhost:8085';

test.describe('Cancer Analysis Portal - Functional Scenarios', () => {

  test('should load homepage correctly', async ({ page }) => {
    await page.goto(BASE);
    await expect(page.getByRole('heading', { name: /cancer analysis portal/i })).toBeVisible();
    await expect(page.getByLabel('Patient Name')).toBeVisible();
    await expect(page.getByLabel('Age', { exact: true })).toBeVisible();
    await expect(page.getByLabel('Image')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Run Analysis' })).toBeVisible();
  });

  test('positive flow - valid patient image', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Patient Name').fill('John Doe');
    await page.getByLabel('Age', { exact: true }).fill('45');
    await page.setInputFiles('#img', 'tests/assets/sample.png');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toBeEmpty();
    await expect(page.locator('#result')).toBeVisible();
    await expect(page.locator('#pdf')).toHaveAttribute('href', /data:application\/pdf/);
  });

  test('should validate missing patient name', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Age', { exact: true }).fill('50');
    await page.setInputFiles('#img', 'tests/assets/sample.jpg');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toHaveText(/patient name is required/i);
    await expect(page.locator('#result')).toBeHidden();
  });

  test('should validate non-positive or invalid age', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Patient Name').fill('Alice');
    await page.getByLabel('Age', { exact: true }).fill('-5');
    await page.setInputFiles('#img', 'tests/assets/sample.png');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toHaveText(/age must be positive/i);

    // try zero age
    await page.getByLabel('Age', { exact: true }).fill('0');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toHaveText(/age must be positive/i);
  });

  test('should reject missing image', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Patient Name').fill('Bob');
    await page.getByLabel('Age', { exact: true }).fill('60');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toHaveText(/image is required/i);
  });

  test('should reject invalid file format', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Patient Name').fill('Eve');
    await page.getByLabel('Age', { exact: true }).fill('40');
    await page.setInputFiles('#img', 'tests/assets/fake.txt');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#error')).toHaveText(/invalid image/i);
  });

  test('should handle long name and boundary age gracefully', async ({ page }) => {
    await page.goto(BASE);
    const longName = 'A'.repeat(100);
    await page.getByLabel('Patient Name').fill(longName);
    await page.getByLabel('Age', { exact: true }).fill('1');
    await page.setInputFiles('#img', 'tests/assets/sample.png');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#result')).toBeVisible();
  });

  test('should clear previous result when new submission starts', async ({ page }) => {
    await page.goto(BASE);
    await page.getByLabel('Patient Name').fill('Dana');
    await page.getByLabel('Age', { exact: true }).fill('35');
    await page.setInputFiles('#img', 'tests/assets/sample.jpg');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#result')).toBeVisible();

    // New invalid submission clears result
    await page.getByLabel('Patient Name').fill('');
    await page.getByRole('button', { name: 'Run Analysis' }).click();
    await expect(page.locator('#result')).toBeHidden();
    await expect(page.locator('#error')).toHaveText(/patient name is required/i);
  });

});
