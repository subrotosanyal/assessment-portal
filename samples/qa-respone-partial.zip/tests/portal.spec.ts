
import { test, expect } from '@playwright/test';
const BASE = process.env.BASE_URL || 'http://localhost:8085';
test('positive flow only', async ({ page }) => {
  await page.goto(BASE);
  await page.getByLabel('Patient Name').fill('Ana');
  await page.getByLabel('Age').fill('30');
  await page.locator('input[type="file"]').setInputFiles({ name: 'valid.jpg', mimeType: 'image/jpeg', buffer: Buffer.from([0xff,0xd8,0xff]) });
  await page.getByRole('button', { name: 'Run Analysis' }).click();
  await expect(page.getByText('Analysis complete')).toBeVisible();
});
