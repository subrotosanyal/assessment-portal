
from fastapi import FastAPI
app = FastAPI()
users=[]; seq=1
@app.get('/users')
def list_users(): return users
@app.post('/users')
def add_user(u: dict):
    global seq
    u={'id':seq,'name':u.get('name',''),'email':u.get('email','')}; seq+=1; users.append(u); return u
