
from fastapi import FastAPI
import httpx
app = FastAPI()
U='http://user:8001'; T='http://task:8002'
@app.get('/health')
def health(): return {'ok': True}
@app.get('/api/users')
def list_users(): return httpx.get(f'{U}/users').json()
@app.post('/api/users')
def add_user(user: dict): return httpx.post(f'{U}/users', json=user).json()
@app.get('/api/tasks')
def list_tasks(): return httpx.get(f'{T}/tasks').json()
@app.post('/api/tasks')
def add_task(t: dict): return httpx.post(f'{T}/tasks', json=t).json()
@app.get('/api/stats')
def stats():
    u=len(httpx.get(f'{U}/users').json()); t=len(httpx.get(f'{T}/tasks').json()); return {'users':u,'tasks':t}
