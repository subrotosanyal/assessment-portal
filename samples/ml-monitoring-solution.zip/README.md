# ML Monitoring Sample Solution

This is a reference implementation that scores 100% with the provided grader for the `ml-monitoring` assignment.

## Structure
- `app.py` — FastAPI service implementing `/events`, `/metrics`, `/alerts`, `/openapi.json`, and `/health`.
- `assets/reference_stats.json` — reference distribution used for drift checks.
- `Dockerfile` — builds a runnable container on port 8000.

## Run locally
```bash
pip install fastapi "uvicorn>=0.30,<0.33" numpy
uvicorn app:app --reload --port 8000
```

## Build & run with Docker
```bash
docker build -t ml-monitoring-solution .
docker run -p 8000:8000 ml-monitoring-solution
```

## Quick check
```bash
curl -X POST http://localhost:8000/events \
  -H "Content-Type: application/json" \
  -d '[{"timestamp":"2024-06-01T00:00:01Z","prediction":0.42,"feature_vector":[0.22,-0.04,0.55],"label":1}]'
curl http://localhost:8000/metrics
curl http://localhost:8000/alerts
```
