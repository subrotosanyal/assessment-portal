import json
import math
import time
from pathlib import Path
from statistics import mean, pstdev
from typing import Dict, List, Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, validator
from typing import Union


DATA_DIR = Path(__file__).parent / "assets"
REF_PATH = DATA_DIR / "reference_stats.json"


class Event(BaseModel):
    timestamp: str
    prediction: float
    feature_vector: List[float]
    label: Optional[int] = Field(default=None)

    @validator("label")
    def validate_label(cls, v):
        if v is None:
            return v
        if v not in (0, 1):
            raise ValueError("label must be 0 or 1")
        return v


class MetricsStore:
    def __init__(self, reference: Dict):
        self.events: List[Event] = []
        self.latencies_ms: List[float] = []
        self.reference = reference

    def add_events(self, events: List[Event]):
        now = time.time()
        for ev in events:
            self.events.append(ev)
            # calculate latency relative to event timestamp
            try:
                ts_struct = time.strptime(ev.timestamp, "%Y-%m-%dT%H:%M:%SZ")
                ts = time.mktime(ts_struct)
            except Exception:
                ts = now
            self.latencies_ms.append(max((now - ts) * 1000, 0.0))

    def _kl_divergence(self, values: List[float]) -> float:
        ref_hist = self.reference.get("prediction_histogram", [])
        if not ref_hist or not values:
            return 0.0
        # Build histogram based on reference bins
        bins = [b["bin"][0] for b in ref_hist] + [ref_hist[-1]["bin"][1]]
        hist, _ = np.histogram(values, bins=bins)
        p = hist / hist.sum() if hist.sum() else np.ones_like(hist) / len(hist)
        q = np.array([b["prob"] for b in ref_hist], dtype=float)
        q = q / q.sum() if q.sum() else np.ones_like(q) / len(q)
        p_safe = np.where(p == 0, 1e-9, p)
        q_safe = np.where(q == 0, 1e-9, q)
        return float(np.sum(p_safe * np.log(p_safe / q_safe)))

    def metrics(self) -> Dict:
        preds = [e.prediction for e in self.events]
        labels = [e.label for e in self.events if e.label is not None]
        feature_vectors = [e.feature_vector for e in self.events if e.feature_vector]

        data = {
            "count_1h": len(self.events),
            "count_24h": len(self.events),
            "prediction_mean": float(mean(preds)) if preds else 0.0,
            "prediction_std": float(pstdev(preds)) if len(preds) > 1 else 0.0,
            "kl_divergence": self._kl_divergence(preds) if preds else 0.0,
        }

        if self.latencies_ms:
            pct = np.percentile(self.latencies_ms, [50, 95, 99])
            data.update({
                "latency_ms_p50": float(pct[0]),
                "latency_ms_p95": float(pct[1]),
                "latency_ms_p99": float(pct[2]),
            })

        if feature_vectors:
            ref_means = self.reference.get("feature_means", [])
            ref_stds = self.reference.get("feature_stds", [])
            p_values = []
            for idx in range(min(len(ref_means), len(feature_vectors[0]))):
                col = [fv[idx] for fv in feature_vectors]
                diff = abs(mean(col) - ref_means[idx])
                std = ref_stds[idx] if idx < len(ref_stds) and ref_stds[idx] else 0.1
                z = diff / std
                p = math.exp(-z)
                p_values.append(p)
            data["feature_drift_pvalue"] = min(p_values) if p_values else 1.0

        if labels and preds:
            preds_bin = [1 if p >= 0.5 else 0 for p in preds]
            tp = sum(1 for p, y in zip(preds_bin, labels) if p == 1 and y == 1)
            tn = sum(1 for p, y in zip(preds_bin, labels) if p == 0 and y == 0)
            fp = sum(1 for p, y in zip(preds_bin, labels) if p == 1 and y == 0)
            fn = sum(1 for p, y in zip(preds_bin, labels) if p == 0 and y == 1)
            acc = (tp + tn) / len(labels) if labels else 0.0
            prec = tp / (tp + fp) if (tp + fp) else 0.0
            rec = tp / (tp + fn) if (tp + fn) else 0.0
            f1 = (2 * prec * rec / (prec + rec)) if (prec + rec) else 0.0
            data["accuracy"] = acc
            data["f1"] = f1

        return data

    def alerts(self) -> List[Dict]:
        alerts = []
        metrics = self.metrics()
        if metrics.get("feature_drift_pvalue", 1.0) < 0.01:
            alerts.append({"type": "drift", "message": "Feature drift detected", "severity": "high"})
        if metrics.get("kl_divergence", 0.0) > 0.5:
            alerts.append({"type": "prediction_drift", "message": "Prediction distribution drift", "severity": "medium"})
        if not alerts:
            alerts.append({"type": "info", "message": "No active alerts", "severity": "low"})
        return alerts


def load_reference() -> Dict:
    if REF_PATH.exists():
        with open(REF_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


app = FastAPI(title="ML Monitoring Service", version="1.0.0")
store = MetricsStore(load_reference())


@app.post("/events")
async def ingest(payload: Union[Event, list[Event]]):
    if isinstance(payload, list):
        events = payload
    else:
        events = [payload]
    store.add_events(events)
    return {"accepted": len(events)}


@app.get("/metrics")
async def get_metrics():
    return store.metrics()


@app.get("/alerts")
async def get_alerts():
    return store.alerts()


@app.get("/health")
async def health():
    return {"ok": True}
