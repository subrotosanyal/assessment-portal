# Claims Intake Portal - Test Plan

## Scope & Risks
- Validate client-side rules: required claim id/email, format for id/email, date not in future, description length, PDF-only evidence.
- Ensure successful submission reveals summary token and clears errors.
- File handling edge cases: missing file, wrong extension.

## Approach
- Exploratory session to note UX and any unexpected behaviors.
- Automate critical happy path and high-value negative checks with Playwright in headed=false, baseURL from env.
- Use fixture PDF stored in `tests/sample-data/evidence.pdf`.

## Test Cases (automated)
1. Empty submission shows all validation messages.
2. Future date and non-PDF evidence trigger specific errors.
3. Valid submission generates summary token and displays echoed values.

## Exit Criteria
- All automated cases passing.
- Known defects logged in `bug-report.md` with repro steps.
