# Exploratory Notes

- Charter: Explore validation UX and result summary for claims intake.
- Environment: Local grader UI at http://localhost:8090 on Playwright chromium (headless), test data in `tests/sample-data`.
- Observations:
  - Error box collapses correctly after fixing inputs.
  - Incident Type is optional; summary shows "Unspecified" when empty (logged as BUG-001).
- Follow-ups: Ask PM if incident type must be mandatory; add boundary tests for 6-digit claim id (leading zeros) and very long descriptions.
