# Bug Report

| ID | Area | Severity | Steps | Expected | Actual |
| --- | --- | --- | --- | --- | --- |
| BUG-001 | Incident Type | Low | Open app -> leave Incident Type blank -> fill other fields valid -> Run Checks | Should require selecting a type or default to a value. | Submission succeeds with type shown as "Unspecified". |
