import { test, expect } from '@playwright/test'
import path from 'path'

const evidencePath = path.join(__dirname, 'sample-data/evidence.pdf')

const today = () => new Date().toISOString().split('T')[0]

const futureDate = () => {
  const d = new Date()
  d.setDate(d.getDate() + 2)
  return d.toISOString().split('T')[0]
}

test('shows validation messages when submitting empty form', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('button', { name: 'Run Checks' }).click()

  await expect(page.getByText('Claim ID is required')).toBeVisible()
  await expect(page.getByText('Email is required')).toBeVisible()
  await expect(page.getByText('Description must be at least 20 characters')).toBeVisible()
  await expect(page.getByText('Evidence is required')).toBeVisible()
})

test('rejects future date and non-PDF evidence', async ({ page }) => {
  await page.goto('/')

  await page.fill('#claimId', '123456')
  await page.fill('#email', 'qa@example.com')
  await page.fill('#date', futureDate())
  await page.selectOption('#type', 'Property')
  await page.fill('#desc', 'Future date should be rejected by validation')

  await page.locator('#evidence').setInputFiles({ name: 'evidence.txt', mimeType: 'text/plain', buffer: Buffer.from('not pdf') })

  await page.getByRole('button', { name: 'Run Checks' }).click()

  await expect(page.getByText('Incident date cannot be in the future')).toBeVisible()
  await expect(page.getByText('Evidence must be a PDF')).toBeVisible()
})

test('accepts valid submission and shows summary', async ({ page }) => {
  await page.goto('/')

  await page.fill('#claimId', '654321')
  await page.fill('#email', 'valid@example.com')
  await page.fill('#date', today())
  await page.selectOption('#type', 'Medical')
  await page.fill('#desc', 'Patient slipped and fractured ankle, seeking urgent review.')
  await page.locator('#evidence').setInputFiles(evidencePath)

  await page.getByRole('button', { name: 'Run Checks' }).click()

  const summary = page.locator('#summary')
  await expect(summary).toBeVisible()
  await expect(page.getByText('CLAIM-654321')).toBeVisible()
  await expect(page.getByText('valid@example.com')).toBeVisible()
  await expect(page.locator('#sumType')).toHaveText('Medical')
  await expect(page.getByText(today())).toBeVisible()
})
